<!DOCTYPE html> 
<html lang="en" dir="ltr>
 
<head> 
<meta charset="utf-8"> 
<title> Home </title> 
<link rel="stylesheet" href="CSS/style3.css">

 </head>                                            
                                       
    <body>
        <nav>
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="login.php">Log In</a></li>
                <li><a href="registration.php">Register</a></li>
            </ul>
        </nav>




                
            <div class="animation">
                    
            <div class="ab">
                
            <h2> Online Project Management System </h2>
            <h3> Organize and plan your projects with teammates </h3>                                        
                                                  
            </div>
                    
                <ul class="box-area">
                                    
                                    <li></li> 
                                    <li></li>
                </ul>                    
 </div>
 </body>        